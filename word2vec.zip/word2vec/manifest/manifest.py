import re
import string
from glob import glob
import os
from os.path import basename
from pathlib import Path
a =[]
b = []
def nom_fichier():
	for p in glob('*.xml'):
		a.append(p)
	return a
def manifest():
	b = nom_fichier()
	
	for fichier in b:
		m = re.search('[^.]*',fichier)
		nom_fichier_sortant = m.group(0)+".txt"
		lines = open(fichier,'r').readlines()
		new_line = " "
		
		with open("traiter/"+nom_fichier_sortant ,'w+') as f:
			for line in lines:
				if "uses-permission" in line:
					    new_line = line.split('"')
					    #new = " ".join("".join([" " if ch in string.punctuation else ch for ch in new_line[1]]).split())
					    f.write(new_line[1]+", ")
					    
				if "action" in line or "category" in line:
					    new_line = line.split('"')
					    #new = " ".join("".join([" " if ch in string.punctuation else ch for ch in new_line[1]]).split())
					    f.write(new_line[1]+", ")
					    
	return 0
if __name__ == "__main__":
	manifest()
	
	
	
	#with open('manifest/traiter/'+element,'r') as f :
	#	lines = f.readlines()
	#	fichiers = [f for f in listdir('manifest/traiter/') if isfile(join('manifest/traiter/', f))]
	#	sents = [[token.lower() for token in line.split(',')] for line in lines] 
	#	print(sents)
	#	model = Word2Vec(sents,window=3, size=20,min_count=1, workers=4)
	#	fname = get_tmpfile("vectors.kv")
	#	model.wv.save(fname)
	#	l = model.most_similar(positive=['permission'], topn=5)
	#	print(l)
	#	print(model.wv['permission'])
	#	print("cv_to_matrix model saved")
