#/bin/sh
#je dois etre dans le dossier dex2jar pour l'executer
for fichier in *.xml
do	
	a="${fichier%%.*}"
	touch "$a".txt
	python3 ./manifest.py "$fichier" "$a".txt
	cp "$a".txt traiter/
	
	
	
	
	
	
done
